import java.util.List;

public class cliente_gestão {

    public void listar_anuncios(){
        String sql = "Select * from anuncios";
    }
    public void obter_detalhes(){

    }
    public void aprovar_anuncio(){
    }
    public void alterar_estado(){}
}
