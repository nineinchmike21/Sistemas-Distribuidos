import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author miguel
 */

interface arrendar extends java.rmi.Remote{

    public String registaranuncio() throws RemoteException;

    public void listar_oferta() throws java.rmi.RemoteException, SQLException;

    public void listar_procura() throws java.rmi.RemoteException, SQLException;

    public void listar_anunciante() throws java.rmi.RemoteException, SQLException;

    public void consultar() throws java.rmi.RemoteException, SQLException;

    public void aid() throws java.rmi.RemoteException;

    public void send_new_msg() throws java.rmi.RemoteException;

    public void consult_msgs() throws java.rmi.RemoteException;
}
public class client extends UnicastRemoteObject implements arrendar{

    Connection con= null;
    Statement stmt= null;
    String location ="";
    String preco = "";
    String genero="";
    String data = "";
    String anunciante ="";
    String tipologia = "";
    String tipo = "";
    String estado ="";

    private static final String PG_HOST = "localhost";
    private static final String PG_DB = "bd2";
    private static final String USER = "l37884";
    private static final String PWD = "teste";
    private static final int port = 1099;

    protected client() throws RemoteException {
        super();
    }

    
    public String registaranuncio(){
        return "INSERT INTO anuncios "+ "VALUES(Malagueira,400,feminino,05-10-2022,Rita,t1,procura,inactivo)";
    }

    
    public void listar_oferta() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'oferta' and estado = 'ativo'";
    }

    
    public void listar_procura() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'procura' and estado = 'ativo'";
    }

    
    public void listar_anunciante() throws RemoteException {
        //
        String sql = "SELECT anunciante FROM anuncios";

    }

    
    public void consultar() throws RemoteException {
        //
        String sql = "Select * from anuncios where anunciante = '?'";
    }

   
    public void aid() throws RemoteException {
        //
        String sql = "Select * from anuncios where aid = '?'";
    }

    
    public void send_new_msg() throws RemoteException {
        //mandar msg ao anunciante

    }

    
    public void consult_msgs() throws RemoteException {
        //consultar msgs recebidas
    }

    public static void main(String[] args) throws RemoteException, SQLException{

        try{
            String url = "jdbc:postgresql://host:port/database";

                Class.forName("org.postgresql.Driver");
                Connection conn = DriverManager.getConnection(url,"miguel","teste");
                System.out.println("Ligaçao estabelecida.... ");
                Statement stmt = conn.createStatement();
            DriverManager.getConnection("jdbc:postgresql://" + PG_HOST + ":1099/" + PG_DB,
                    USER,
                    PWD);
            Statement st = conn.createStatement();
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Malagueira,400,feminino,05-10-2022,Rita,t1,procura,inactivo)");
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Horta das Figueiras,200,masculino,15-11-2022.Nuno,t1,oferta,inativo)");
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Centro Historico,300,masculino,15-11-2022.Ricardo,t0,oferta,inativo)");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
