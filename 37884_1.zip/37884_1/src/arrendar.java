import java.rmi.RemoteException;
import java.sql.SQLException;

public interface arrendar extends java.rmi.Remote{

    public String registaranuncio() throws RemoteException;

    public void listar_oferta() throws java.rmi.RemoteException, SQLException;

    public void listar_procura() throws java.rmi.RemoteException, SQLException;

    public void listar_anunciante() throws java.rmi.RemoteException, SQLException;

    public void consultar() throws java.rmi.RemoteException, SQLException;

    public void aid() throws java.rmi.RemoteException;

    public void send_new_msg() throws java.rmi.RemoteException;

    public void consult_msgs() throws java.rmi.RemoteException;
}
