import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;

/**
 *
 * @author miguel
 */
interface arrendar extends java.rmi.Remote{

    public String registaranuncio() throws RemoteException;

    public void listar_oferta() throws java.rmi.RemoteException, SQLException;

    public void listar_procura() throws java.rmi.RemoteException, SQLException;

    public void listar_anunciante() throws java.rmi.RemoteException, SQLException;

    public void consultar() throws java.rmi.RemoteException, SQLException;

    public void aid() throws java.rmi.RemoteException;

    public void send_new_msg() throws java.rmi.RemoteException;

    public void consult_msgs() throws java.rmi.RemoteException;
}
class client extends UnicastRemoteObject implements arrendar{

    Connection con= null;
    Statement stmt= null;
    String location ="";
    String preco = "";
    String genero="";
    String data = "";
    String anunciante ="";
    String tipologia = "";
    String tipo = "";
    String estado ="";

    private static final String PG_HOST = "localhost";
    private static final String PG_DB = "bd2";
    private static final String USER = "l37884";
    private static final String PWD = "teste";
    private static final int port = 1099;

    protected client() throws RemoteException {
        super();
    }

    
    public String registaranuncio(){
        return "INSERT INTO anuncios "+ "VALUES(Malagueira,400,feminino,05-10-2022,Rita,t1,procura,inactivo)";
    }

    
    public void listar_oferta() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'oferta' and estado = 'ativo'";
    }

    
    public void listar_procura() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'procura' and estado = 'ativo'";
    }

    
    public void listar_anunciante() throws RemoteException {
        //
        String sql = "SELECT anunciante FROM anuncios";

    }

    
    public void consultar() throws RemoteException {
        //
        String sql = "Select * from anuncios where anunciante = '?'";
    }

   
    public void aid() throws RemoteException {
        //
        String sql = "Select * from anuncios where aid = '?'";
    }

    
    public void send_new_msg() throws RemoteException {
        //mandar msg ao anunciante
        
    }

    
    public void consult_msgs() throws RemoteException {
        //consultar msgs recebidas
    }

public class server extends client{
    private String userName = "l37884";
    private String password = "teste";

    protected server() throws RemoteException {
    }

    private Connection getConnection(){
        try{
            con = DriverManager.getConnection(getConnectionUrl(), userName, password);
            if (con != null) {
                System.out.println("Connection Successful!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
    private void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
            con = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String args[]) {

        int regPort= 1099; // default RMIRegistry port

        String connectionUrl = "jdbc:postgresql://localhost/postgres?user=miguel&password=teste&ssl=false";
        String insertSql = "INSERT INTO anuncio "+ "VALUES(2,'portalegre',400,'feminino','20/11/2022','rita','t1','procura','inactivo')";
        ResultSet resultSet = null;

        try (Connection connection = DriverManager.getConnection(connectionUrl); PreparedStatement prepsInsertProduct = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);) {
            prepsInsertProduct.execute();
            // Retrieve the generated key from the insert.
            resultSet = prepsInsertProduct.getGeneratedKeys();

            // Print the ID of the inserted row.
            while (resultSet.next()) {
                System.out.println("Generated: " + resultSet.getString(1)+resultSet.getString(2));
            }
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getConnectionUrl() {
        return "jdbc:postgresql://localhost/test?user=l37884&password=teste&ssl=false";
    }
}
