package com.mycompany.trabalho2.Cliente;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.json.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author miguel
 */

interface arrendar extends java.rmi.Remote{

    public String registaranuncio(int aid,String localizacao,int preco,String data,String anunciante,String tipo_aloj,String tipo, String estado) throws RemoteException;

    public void listar_oferta() throws java.rmi.RemoteException, SQLException;

    public void listar_procura() throws java.rmi.RemoteException, SQLException;

    public void listar_anunciante() throws java.rmi.RemoteException, SQLException;

    public List<String> consultar() throws java.rmi.RemoteException, SQLException;

    public int aid() throws java.rmi.RemoteException;

    public void send_new_msg() throws java.rmi.RemoteException;

    public void consult_msgs() throws java.rmi.RemoteException;
}
public class client extends UnicastRemoteObject implements arrendar{

    Connection con= null;
    Statement stmt= null;
    String location ="";
    String preco = "";
    String genero="";
    String data = "";
    String anunciante ="";
    String tipologia = "";
    String tipo = "";
    String estado ="";

    private static final String PG_HOST = "localhost";
    private static final String PG_DB = "bd1";
    private static final String USER = "l37884";
    private static final String PWD = "teste";
    private static final int port = 1099;

    protected client() throws RemoteException {
        super();
    }

    public static int menu(){
        int opcao;
        Scanner sc = new Scanner(System.in);
        System.out.println("Escolha uma opção :\n"+
                " 1- Registar anuncio\n"+
                " 2- Listar oferta \n"+
                " 3- Procurar anuncio\n"+
                " 4- Obter detalhes anuncio\n"+
                " 5- Enviar mensagem ao anunciante\n");
        try{
            System.out.println("Opção: ");
            opcao = sc.nextInt();
        }catch(Exception e){
            opcao = 6;
        }
        return opcao;
    }
    public static String registaranuncio(int aid ) throws Exception{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        HttpURLConnection con =(HttpURLConnection) DriverManager.getConnection("//localhost:8080/bd1","l37884", "teste");
        Scanner sc = new Scanner(System.in);
        String values;
        List<String> arr = new List<String>();
        Statement stmt = con.createStatement();
        for(int i =0;i<=9;i++){
           values = sc.nextLine();
           arr.add(values);
        }
        for(int j =0;j < arr.size() ;j++){
            stmt.executeUpdate("Insert into anuncios( "+ arr.get(j) +" )");
        }
        /*try{
            HttpURLConnection connection= (HttpURLConnection) new URL(PG_HOST).openConnection();
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            
            String jsonObject = "INSERT INTO anuncios "+ "VALUES(" + aid+this.location+","+this.preco+","+this.genero+","+ this.data+"," + this.anunciante+","+ this.tipologia +","+ this.tipo +","+ this.estado+ " )";
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonObject.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
        }catch(Exception e){
            e.printStackTrace();
        }*/
        return "INSERT INTO anuncios "+ "VALUES("+this.location+","+this.preco+","+this.genero+","+ this.data+"," + this.anunciante+","+ this.tipologia +","+ this.tipo +","+ this.estado+ " )";
    }

    
    public void listar_oferta() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'oferta' and estado = 'ativo'";
    }

    
    public void listar_procura() throws RemoteException {
        //
        String sql = "SELECT tipo FROM anuncios WHERE tipo = 'procura' and estado = 'ativo'";
    }

    
    public List<String> consultar() throws RemoteException {
        //
        String sql = "Select * from anuncios where anunciante = '?'";
        //devolver dados em formato lista
        List<String> dados = new List<String>();
        return dados;
    }
    
    public static JSONArray convertJSONStringtoArray(String json){
        return new JSONArray(json);
    }
   
    public int aid() throws RemoteException { //
        //
        String sql = "Select * from anuncios where aid = '?'";
        int aid = JSON.parseInt();// 
        return aid;
    }

    
    public void send_new_msg() throws RemoteException {
        //mandar msg ao anunciante

    }

    
    public void consult_msgs() throws RemoteException {
        //consultar msgs recebidas
    }

    public static void main(String[] args) throws RemoteException, SQLException{
        try{
            String url = "jdbc:postgresql://host:port/database";

                Class.forName("org.postgresql.Driver");
                Connection conn = DriverManager.getConnection(url,"miguel","teste");
                System.out.println("Ligaçao estabelecida.... ");
                Statement stmt = conn.createStatement();
            DriverManager.getConnection("jdbc:postgresql://" + PG_HOST + ":1099/" + PG_DB,
                    USER,
                    PWD);
            Statement st = conn.createStatement();
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Malagueira,400,feminino,05-10-2022,Rita,t1,procura,inactivo)");
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Horta das Figueiras,200,masculino,15-11-2022.Nuno,t1,oferta,inativo)");
            st.executeUpdate("INSERT INTO anuncios "+ "VALUES(Centro Historico,300,masculino,15-11-2022.Ricardo,t0,oferta,inativo)");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
