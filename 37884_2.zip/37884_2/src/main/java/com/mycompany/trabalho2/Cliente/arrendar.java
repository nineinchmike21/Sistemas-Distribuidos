import java.rmi.RemoteException;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONObject;

public interface arrendar extends java.rmi.Remote{

    public String registaranuncio() throws RemoteException;

    public void listar_oferta() throws java.rmi.RemoteException, SQLException;

    public void listar_procura() throws java.rmi.RemoteException, SQLException;

    public void listar_anunciante() throws java.rmi.RemoteException, SQLException;

    public void consultar() throws java.rmi.RemoteException, SQLException;

    public int get_aid(String f);

    public void send_new_msg() throws java.rmi.RemoteException;

    public void consult_msgs() throws java.rmi.RemoteException;
}
