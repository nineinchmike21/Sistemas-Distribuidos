/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.trabalho2.Servidor;

import org.glassfish.grizzly.http.server.HttpServer;
import java.io.IOException;
import java.net.URI;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

/**
 *
 * @author miguel
 */
public class Servidor {
    
    private static int getPort(int defaultPort) {
        return defaultPort;
    }
    private static URI getBaseURI() {
        return URI.create("");
    }
    public static final URI BASE_URI = getBaseURI();

    public static org.glassfish.grizzly.http.server.HttpServer startServer() throws IOException {
        // ativar um servico com os REST resources existentes neste pacote:
        ResourceConfig rc = new ResourceConfig().packages("com/mycompany/trabalho2");

        return GrizzlyHttpServerFactory.createHttpServer(BASE_URI, rc);
    }
    public static void main(String[] args) throws IOException{
        System.out.println("Começar servidor...");
        HttpServer server = startServer();
        
        System.out.println("\n## Para um primeiro teste, veja isto no browser: " + BASE_URI + "turma");
        System.out.println("\n## Hit enter to stop the server...");

        System.in.read();
        // depois do enter:
        server.stop();
    }
}
