/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho2.Servidor;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author miguel
 */
public class Query {
    public Query(){
        super();
    }
    
    public List<String> mostrarAnuncio(String filtro){
        Scanner sc = new Scanner(System.in);
        String anuncio= sc.nextLine();
        String query;
        switch(filtro){
            case "ativo":
                query = "SELECT * FROM anuncios WHERE estado = " + anuncio;
                break;
            case "inativo":
                break;
        }
        return null;
    }
}
