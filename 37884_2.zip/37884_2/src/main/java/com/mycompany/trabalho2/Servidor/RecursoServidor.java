/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho2.Servidor;

import jakarta.ws.rs.*;
/**
 *
 * @author miguel
 */
public class RecursoServidor {
    private Query query ;
    
    public RecursoServidor(){
        this.query =  new Query();
    }
    
    @Path("/anuncios")
    @GET
    @Produces({"application/json"})
    public synchronized String registaranuncio(){
        return ;
    }
    
}
public 
