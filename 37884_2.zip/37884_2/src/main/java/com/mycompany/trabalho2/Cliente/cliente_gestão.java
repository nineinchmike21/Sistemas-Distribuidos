import java.util.List;
import java.sql.*;

public class cliente_gestão {

    public void listar_anuncios() throws Exception{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:8080/bd1","l37884", "");
        String query = "SELECT * FROM anuncios WHERE estado= ativo";
    }
    public void obter_detalhes(){
        String query = "SELECT * FROM anuncios WHERE estado= ativo where";
    }
    public void aprovar_anuncio() throws Exception{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:8080/bd1","l37884", "");
        
        Statement stmt = con.createStatement();
        String query = "UPDATE bd1 SET estado = ativo WHERE estado = inativo";
        stmt.execute(query);
    }
    public void alterar_estado(String aid) throws Exception{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:8080/bd1","l37884", "");
        String query1="UPDATE bd1 SET estado = ativo WHERE estado = inativo";
        String query2 = "UPDATE bd1 SET estado = inativo WHERE estado=ativo";
        String query3 = "Select estado from anuncios where aid = " +aid;
        Statement stmt = con.createStatement();
        String s = toString(stmt.execute(query3));
        if(s =="ativo"){
            Statement stmt2 = con.createStatement();
            stmt.execute(query1);
        }else{
            Statement stmt2 = con.createStatement();
            stmt.execute(query2);
        }
    }

    private String toString(boolean execute) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
